
// ======= MEAN MENU OPTIONS START =======

// SEARCH CATEGORY

$('#cat_search_btn').on('click', function() {
    $('#cat_items').slideToggle();
})

// MENU CATEGORY
$( "#cat_list_btn" ).on( "click", function() {
  $( "#cat_show_items" ).slideToggle( "fast", function() {
    // Animation complete.
  });
});


// MOBILE MENU

$(document).ready(function () {
    $('#mainnav').meanmenu({
        meanMenuContainer: '.mobile-menu-updated',
        meanScreenWidth: "991",
        meanExpand: ['+'],
        meanClose: ['-'],
        meanMenuClose: '<i class="fa-solid fa-xmark"></i>'
    });
});



// HOME PAGE 1 SLIDER
$(".home_one_slider").owlCarousel({
	items: 1,
	loop: true,
	autoplay: false,
	margin: 50,
	dots: true,
	paginationSpeed: 300,
	rewindSpeed: 400,
});

// HOME PAGE 1 MIXITUP
const mixer = document.querySelector('.mixitup_products_row');
if(mixer){
    mixitup('.mixitup_products_row');
}

// HOME PAGE 1 TESTOMONIAL
$(".home_one_testimoial").owlCarousel({
	items: 4,
	loop: true,
	autoplay: false,
	margin: 30,
	dots: false,
	paginationSpeed: 300,
	rewindSpeed: 400,
	navContainer: ".kh_testimonial_nav",
	navText : ["<i class='fa fa-chevron-left'></i>","<i class='fa fa-chevron-right'></i>"],
	responsiveClass:true,
  responsive: {
    0: {
        items: 1,
        center: true,
    },

    480: {
        items: 2,
        center: false,
    },

    576: {
        items: 2,
    },

    768: {
        items: 2,
    },

    992: {
        items: 3,
    },

    1200: {
       items: 4,
       margin: 30,
   }
}
});

// NICE SELECT
$(document).ready(function() {
  $('select').niceSelect();
});


// HOME PAGE 2 HEADER SEARCH
$(document).ready(function(){
    $('a[href="#search"]').on('click', function(event) {                    
        $('#search').addClass('open');
        $('#search > form > input[type="search"]').focus();
    });            
    $('#search, #search button.close').on('click keyup', function(event) {
        if (event.target == this || event.target.className == 'close' || event.keyCode == 27) {
            $(this).removeClass('open');
        }
    });            
});





// HOME PAGE 2 TESMONILA
$(".home_two_testimonial").owlCarousel({
    items: 1,
    loop: true,
    autoplay: false,
    margin: 50,
    dots: true,
    paginationSpeed: 300,
    rewindSpeed: 400,
});


// HOME PAGE 3 CATEGORY
$(".home_3_catogory").owlCarousel({
    items: 6,
    loop: true,
    autoplay: false,
    margin: 50,
    dots: false,
    paginationSpeed: 300,
    rewindSpeed: 400,
    navContainer: ".kh_home_3_category_nav",
    navText : ["<i class='fa fa-chevron-left'></i>","<i class='fa fa-chevron-right'></i>"],
    responsiveClass:true,
    responsive: {
        0: {
            items: 1,
            center: true,
        },

        480: {
            items: 2,
            center: false,
        },

        575: {
            items: 2,
        },

        768: {
            items: 3,
        },

        992: {
            items: 4,
        },

        1200: {
            items: 6,
            margin: 30,
        }
    }
});

// HOME PAGE 3 CATEGORY
$(".home_3_popular_product").owlCarousel({
    items: 6,
    loop: true,
    autoplay: false,
    margin: 30,
    dots: false,
    paginationSpeed: 300,
    rewindSpeed: 400,
    navContainer: ".kh_home_3_product_nav",
    navText : ["<i class='fa fa-chevron-left'></i>","<i class='fa fa-chevron-right'></i>"],
    responsiveClass:true,
    responsive: {
        0: {
            items: 1,
            center: true,
        },

        480: {
            items: 1,
            center: false,
        },

        576: {
            items: 2,
        },

        768: {
            items: 3,
        },

        992: {
            items: 4,
        },

        1200: {
            items: 5,
            margin: 30,
        }
    }
});


// HOME PAGE 3 TIMER

$(".product_deal_countdown").syotimer({
    date: new Date(2023, 12, 24, 15),
    periodic: true,
    periodInterval: 10,
    periodUnit: "d",
});


// ABOUT US VENOBOX 
new VenoBox({
  selector: '.my_video'
});


// SIDEBAR PRICE FILTER
var skipSlider = document.getElementById("skipstep");
var skipValues = [
document.getElementById("skip-value-lower"),
document.getElementById("skip-value-upper")
];
if(skipSlider){
    noUiSlider.create(skipSlider, {
        start: [100, 900],
        connect: true,
        behaviour: "drag",
        step: 1,
        range: {
            min: 100,
            max: 900
        },
        format: {
            from: function (value) {
                return parseInt(value);
            },
            to: function (value) {
                return parseInt(value);
            }
        }
    });

    skipSlider.noUiSlider.on("update", function (values, handle) {
        skipValues[handle].innerHTML = values[handle];
    });
}
// SIDEBAR PRICE FILTER

var skipSlider1 = document.getElementById("skipstep1");
var skipValues1 = [
document.getElementById("skip-value-lower1"),
document.getElementById("skip-value-upper1")
];
if(skipSlider1){
    noUiSlider.create(skipSlider1, {
        start: [100, 900],
        connect: true,
        behaviour: "drag",
        step: 1,
        range: {
            min: 100,
            max: 900
        },
        format: {
            from: function (value) {
                return parseInt(value);
            },
            to: function (value) {
                return parseInt(value);
            }
        }
    });

    skipSlider1.noUiSlider.on("update", function (values, handle) {
        skipValues1[handle].innerHTML = values[handle];
    });
}
// SIDEBAR PRICE FILTER
$(document).ready(function () { 
    $('#btnUncheckAll').click(function () { 
        $('input[type=checkbox]').each( 
          function (index, checkbox) { 
            if (index != 0) { 
                checkbox.checked = false; 
            } 
        }); 
    }); 
}); 


// SIDEBAR CHEAKBOX
$("input:checkbox").on('click', function() {
  var $box = $(this);
  if ($box.is(":checked")) {
    var group = "input:checkbox[name='" + $box.attr("name") + "']";
    $(group).prop("checked", false);
    $box.prop("checked", true);
} else {
    $box.prop("checked", false);
}
});

// SIDEBAR COLOR ACTIVE
if (header) {
    var header = document.getElementById("myDIV");
    var btns = header.getElementsByClassName("btn");

    for (var i = 0; i < btns.length; i++) {
      btns[i].addEventListener("click", function() {
          var current = document.getElementsByClassName("active");
          current[0].className = current[0].className.replace(" active", "");
          this.className += " active";
      });
  }
}
// SHOP PRODUCT VIEW TAB
function productView(evt, productNAME) {
  var i, tabcontent, tablinks;
  tabcontent = document.getElementsByClassName("tabcontent");
  for (i = 0; i < tabcontent.length; i++) {
    tabcontent[i].style.display = "none";
}
tablinks = document.getElementsByClassName("tablinks");
for (i = 0; i < tablinks.length; i++) {
    tablinks[i].className = tablinks[i].className.replace(" active", "");
}
document.getElementById(productNAME).style.display = "block";
evt.currentTarget.className += " active";
}

// SHOP INCREAMENT NUMBER
let nums = document.querySelectorAll("input[type='number']");
nums.forEach(function(e){
  e.addEventListener("input",function(el){
    el.target.value = parseInt(el.target.value)    
});
});



// SHOP DETAILS SLIDER
var swiper = new Swiper(".sldier_thumb_area", {
  loop: true,
  spaceBetween: 10,
  slidesPerView: 4,
  freeMode: true,
  watchSlidesProgress: true,
});
var swiper2 = new Swiper(".mySwiper2", {
  loop: true,
  spaceBetween: 10,
  navigation: {
    nextEl: ".swiper-button-next",
    prevEl: ".swiper-button-prev",
},
thumbs: {
    swiper: swiper,
},
});

// SHOP DETAILS IMAGE
$(".client-img").on("click", function () {
    var clientProduct = $(this).find("img").attr("src");
    $(this).addClass("active").siblings().removeClass("active");
    $(this).parent().siblings(".view-panel").addClass("active");
    $(this).parents(".single-review").siblings().find(".client-img").removeClass("active");
    $(this).parents(".single-review").siblings().find(".view-panel").removeClass("active");
    $(".client-product").attr("src", clientProduct);
});
$(".clt-view-panel-close").on("click", function () {
    $(".client-product").attr("src", "");
    $(".gallery-wrap .view-panel").removeClass("active");
    $(".client-img").removeClass("active");
});

function increment(max) {
    document.getElementById("myNumber").value = parseInt(document.getElementById("myNumber").value) + 1;
    if (document.getElementById("myNumber").value >= parseInt(max)) {
        document.getElementById("myNumber").value = max;
    }
}
function decrement(min) {
    document.getElementById("myNumber").value = parseInt(document.getElementById("myNumber").value) - 1;
    if (document.getElementById("myNumber").value <= parseInt(min)) {
        document.getElementById("myNumber").value = min;
    }
}

// ACCOUNT LOGIN PAGE

$(".toggle-password").click(function() {

  $(this).toggleClass("fa-eye fa-eye-slash");
  var input = $($(this).attr("toggle"));
  if (input.attr("type") == "password") {
    input.attr("type", "text");
} else {
    input.attr("type", "password");
}
});

$("#toggle-password").click(function() {

  $(this).toggleClass("fa-eye fa-eye-slash");
  var input = $($(this).attr("toggle"));
  if (input.attr("type") == "password") {
    input.attr("type", "text");
} else {
    input.attr("type", "password");
}
});

// Animated

AOS.init({
  once: true, 
});