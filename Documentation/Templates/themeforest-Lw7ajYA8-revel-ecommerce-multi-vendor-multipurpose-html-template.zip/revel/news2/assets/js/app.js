$('.search-toggle').click(function() {
    $('.search-input').toggleClass('active');
    $('.empty-div').toggleClass('active');
});
$('.empty-div').click(function() {
        $(this).removeClass('active');
        $('.search-input').removeClass('active');

    })
    // FOR NAVBAR FIXED WHEN SCROLL
$(window).on("scroll", function() {
    var scrolling = $(this).scrollTop();
    if (scrolling > 30) {
        $(".navigation").addClass("navbar-fixed");
    } else {
        $(".navigation").removeClass("navbar-fixed");
    }
});

// ===================top post slider===========
var swiper = new Swiper(".top-news-slider", {
    slidesPerView: 1,
    spaceBetween: 30,
    loop: true,
    autoPlay: true,
    keyboard: {
        enabled: true,
    },

    breakpoints: {
        860: {
            slidesPerView: 3,
        },
        550: {
            slidesPerView: 2,
        },
    },
});
// =============navbar toggle============
let showMenu = document.querySelector('#showMenu');
let menu = document.querySelector('.mobile-menu');
showMenu.addEventListener('click', function() {
    menu.classList.add('active');
});

let closeMenu = document.querySelector('.close-menu');

closeMenu.addEventListener('click', function() {
    menu.classList.remove('active');
});

// FOR FAQ SECTION ACCORDION
$(function($) {
    var panels = $(".faq-ans").hide();
    panels.first().show();

    $(".faq-que").click(function() {
        var $this = $(this);
        panels.slideUp();
        $this.next().slideDown();
    });
});

$(".faq-que").click(function() {
    $(".faq-que").removeClass("active");
    $(this).addClass("active");
    $(".faq-que i").addClass("icofont-plus");
    $(this.children[1]).removeClass("icofont-plus");
    $(this.children[1]).addClass("icofont-minus");
});
// ======preloader=======
setTimeout(function() {
        document.getElementById("preloader").style.opacity = "0";
        document.getElementById("preloader").style.visibility = "hidden";
    }, 2000)
    // ============product mixitup init===

// ==========message sent ========
function myFunction() {
    alert("Submit Your Message Please wait for reply!!");
}