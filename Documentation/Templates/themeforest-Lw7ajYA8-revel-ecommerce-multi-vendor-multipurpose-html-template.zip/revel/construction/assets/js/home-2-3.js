(function($) {
    "use strict";
    jQuery(document).ready(function($) {
        // section animated & levelling
        var $sectionAbout = $('#aboutTxt');
        var $sectionFeatures = $('#aboutImg');
        $(window).on("scroll", function() {
            var scrollOffset = $(document).scrollTop();
            var containerOffset2 = $sectionAbout.offset().top - window.innerHeight;
            var containerOffset3 = $sectionFeatures.offset().top - window.innerHeight;

            if (scrollOffset > containerOffset2) {
                $sectionAbout.addClass('animated');
            }

            if (scrollOffset > containerOffset3) {
                $sectionFeatures.addClass('animated');
            }
        });

        // ========odometer init========
        $('.odometer').appear(function(e) {
            var odo = $(".odometer");
            odo.each(function() {
                var countNumber = $(this).attr("data-count");
                $(this).html(countNumber);
            });
        });

        // ========banner slider for home page 3==========
        $('.text-carousel').slick({
            slidesToShow: 1,
            slidesToScroll: 1,
            arrows: false,
            asNavFor: '.image-carousel'
        });
        $('.image-carousel').slick({
            slidesToShow: 1,
            slidesToScroll: 1,
            asNavFor: '.text-carousel',
            dots: false,
            autoplay: true,
            prevArrow: '<button type="button" class="slick-prev"><i class="icofont-thin-left"></i></button>',
            nextArrow: '<button type="button" class="slick-next"><i class="icofont-thin-right"></i></button>',
        });
    });

}(jQuery));