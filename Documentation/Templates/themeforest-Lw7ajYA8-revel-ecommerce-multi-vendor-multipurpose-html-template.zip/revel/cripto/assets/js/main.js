(function ($) {
    'use strict';
    $(document).ready(function(){
        //=============== Fixed Header ===============
        $(window).on('scroll', function(){
            if($(this).scrollTop() > 500) {
                $('.rv_header-26').addClass('fixed-header');
            } else {
                $('.rv_header-26').removeClass('fixed-header');
            }
        });


        //=============== Header Search Section ===============
        $(document).on('click', function(event) {
            if (!$(event.target).closest('.header-search-box').length && !$(event.target).hasClass('search-btn')) {
                $('.header-search-box').removeClass('active');
            }
        });
        $('.search-btn').on('click', function(event){
            event.stopPropagation();
            $('.header-search-box').toggleClass('active');
        });


        //=============== Counter Section Count ===============
        const counterElements = document.querySelectorAll('.counter');
        const isElementInViewport = el => {
            const rect = el.getBoundingClientRect();
            return rect.top >= 0 && rect.bottom <= window.innerHeight;
        };
        const updateCounter = (counter, count, step, currentCount) => {
            currentCount += step;
            counter.textContent = Math.min(Math.floor(currentCount), count) + '+';
            if (currentCount < count) requestAnimationFrame(() => updateCounter(counter, count, step, currentCount));
        };
        const updateCountersIfVisible = () => {
            counterElements.forEach(counter => {
                if (isElementInViewport(counter)) {
                    const count = parseInt(counter.getAttribute('data-count'));
                    const step = count / (1500 / 20);
                    updateCounter(counter, count, step, 0);
                    window.removeEventListener('scroll', updateCountersIfVisible);
                }
            });
        };
        window.addEventListener('scroll', updateCountersIfVisible);


        //=============== Client Slider On index-28 ===============
        if($('.owl-carousel').length) {
            $('.client-slider').owlCarousel({
                items: 5,
                loop: true,
                autoplay: true,
                margin: 30,
                dots: false,
                responsive: {
                    0 : {
                        items: 3,
                        margin: 15
                    },
                    576 : {
                        items: 4,
                        margin: 15
                    },
                    992 : {
                        items: 5,
                        margin: 30
                    }
                }
            })
        }


        //=============== Countdown timer On index-28 ===============
        var targetDate = new Date("2024-12-31 00:00:00").getTime();
        var countdownInterval = setInterval(function() {
            var currentDate = new Date().getTime();
            var timeLeft = targetDate - currentDate;

            if (timeLeft <= 0) {
                clearInterval(countdownInterval);
                $("#countdown").html("Countdown expired");
            } else {
                var days = Math.floor(timeLeft / (1000 * 60 * 60 * 24));
                var hours = Math.floor((timeLeft % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
                var minutes = Math.floor((timeLeft % (1000 * 60 * 60)) / (1000 * 60));
                var seconds = Math.floor((timeLeft % (1000 * 60)) / 1000);

                $("#days").text(formatNumber(days));
                $("#hours").text(formatNumber(hours));
                $("#minutes").text(formatNumber(minutes));
                $("#seconds").text(formatNumber(seconds));
            }
        }, 1000);
        function formatNumber(number) {
            return (number < 10 ? "0" : "") + number;
        }
    });
})(jQuery);