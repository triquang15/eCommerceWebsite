// FOR NOTIFICATION ADD CLASS ACTIVE
$("#notification").on('click', function() {
        $(".notify-body").toggleClass('active');
    })
    //LEFT MENU ADD CLASS =================
$("#toggle-id").on('click', function() {
    $(".main-category").addClass('active');
})

//Mobile Menu Dropdown =================
$(".has-sub").on('click', function() {
    $(this).siblings(".dp-menu").toggle(250);
});

$(".toggleClose").on('click', function() {
        $(".main-category").removeClass('active');
    })
    // ======preloader=======
setTimeout(function() {
        document.getElementById("preloader").style.opacity = "0";
        document.getElementById("preloader").style.visibility = "hidden";
    }, 3000)
    // ============product mixitup init===


//MOBILE TOGGLE ID =================
$("#toggle-id-m").on('click', function() {
    $(".main-category").addClass('active');
})

$(".toggleClose-m").on('click', function() {
    $(".main-category").removeClass('active');
})

// =================================MEDIA NEWS===========================
// =============================================================side manu====================

$(document).ready(function() {
    $('.m-cat-list li').on('click', function() {
        $('.m-cat-list li').removeClass('active');
        $(this).addClass('active');
        let menuID = $(this).data('menu')
        $('.latest-post ul li').removeClass('active');
        $('#' + menuID).addClass('active')
    })
})

// ==========================================================
$('.vot-carosel-main').owlCarousel({
    center: true,
    items: 1,
    loop: true,
    margin: 10,
    responsive: {
        0: {
            items: 1,
            nav: false
        },
        600: {
            items: 1,
            nav: false
        },
        1000: {
            items: 1,
            nav: false,
            loop: true,
        }
    }
});

// ============================================DSIS cart bar=======


// FOR NAVBAR FIXED WHEN SCROLL
$(window).on("scroll", function() {
    var scrolling = $(this).scrollTop();
    if (scrolling > 94) {
        $(".sticky").addClass("navbar-fixed");
    } else {
        $(".sticky").removeClass("navbar-fixed");
    }
});

// ===============home 2======
$(document).ready(function() {
    $('.menu-list li').on('click', function() {
        $('.menu-list li').removeClass('active');
        $(this).addClass('active');
        let menuID = $(this).data('menu')
        $('.news-bs-content div').removeClass('active');
        $('#' + menuID).addClass('active')
    })
})

// ============================home 2 carosel =================
$('.hot_news').owlCarousel({
    loop: true,
    autoplay: true,
    margin: 10,
    responsiveClass: true,
    nav: false,
    dots: false,
    responsive: {
        0: {
            items: 1,
            nav: true
        },
        600: {
            items: 3,
            nav: false
        },
        1000: {
            items: 3,
            nav: false,
            loop: true
        }
    }
})

// ============================home 4 carosel section =================
$('.carosel-news').owlCarousel({
    loop: true,
    autoplay: true,
    margin: 10,
    responsiveClass: true,
    nav: false,
    dots: false,
    responsive: {
        0: {
            items: 1,
            nav: true
        },
        600: {
            items: 2,
            nav: false
        },
        1000: {
            items: 4,
            nav: false,
            loop: true
        }
    }
})

// ===============================gallery page========
$('.show-slider-img').owlCarousel({
    loop: true,
    autoplay: true,
    margin: 10,
    responsiveClass: true,
    responsive: {
        0: {
            items: 1,
            nav: false
        },
        600: {
            items: 1,
            nav: false
        },
        1000: {
            items: 1,
            nav: false,
        }
    }
})

// ==============================end===========

// ==========message sent ========
function myFunction() {
    alert("Submit Your Message Please wait for reply!!");
}