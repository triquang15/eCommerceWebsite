var options = {
    series: [{
        name: 'Website Blog',
        type: 'column',
        data: [100, 200, 314, 471, 527, 813, 201, 352, 752, 320, 257, 160]
    }, {
        name: 'Social Media',
        type: 'line',
        data: [23, 42, 35, 27, 43, 22, 17, 31, 22, 22, 12, 16]
    }],
    chart: {
        height: 350,
        type: 'line',
    },
    stroke: {
        width: [0, 4]
    },
    title: {
        text: ''
    },
    dataLabels: {
        enabled: true,
        enabledOnSeries: [1]
    },
    labels: ['01 Jan  2022', '02 Jan  2022', '03 Jan  2022', '04 Jan  2022', '05 Jan  2022', '06 Jan  2022', '07 Jan  2022', '08 Jan  2022', '09 Jan  2022', '10 Jan  2022', '11 Jan  2022', '12 Jan  2022'],
    xaxis: {
        type: 'datetime'
    },
    yaxis: [{
        title: {
            text: 'Today Sale',
        },

    }, {
        opposite: true,
        title: {
            text: 'Product Stock'
        }
    }]
};

var chart = new ApexCharts(document.querySelector("#chart"), options)
chart.render();


// ===============================================chart-1===================
var options = {
    series: [{
        name: 'Website Blog',
        type: 'column',
        data: [40, 505, 304, 471, 527, 413, 601, 752, 852, 920, 1057, 1060]
    }, {
        name: 'Social Media',
        type: 'line',
        data: [23, 42, 35, 27, 43, 22, 17, 31, 22, 22, 12, 16]
    }],
    chart: {
        height: 350,
        type: 'line',
    },
    stroke: {
        width: [0, 4]
    },
    title: {
        text: ''
    },
    dataLabels: {
        enabled: true,
        enabledOnSeries: [1]
    },
    labels: ['01 Jan  2022', '02 Jan  2022', '03 Jan  2022', '04 Jan  2022', '05 Jan  2022', '06 Jan  2022', '07 Jan  2022', '08 Jan  2022', '09 Jan  2022', '10 Jan  2022', '11 Jan  2022', '12 Jan  2022'],
    xaxis: {
        type: 'datetime'
    },
    yaxis: [{
        title: {
            text: 'Today Sale',
        },

    }, {
        opposite: true,
        title: {
            text: 'Product Stock'
        }
    }]
};

var chart = new ApexCharts(document.querySelector("#chart-T"), options)
chart.render();

// ===============================================chart-1===================
var options = {
    series: [{
        name: 'Website Blog',
        type: 'column',
        data: [440, 505, 414, 671, 227, 413, 201, 352, 752, 320, 257, 160]
    }, {
        name: 'Social Media',
        type: 'line',
        data: [23, 42, 35, 27, 43, 22, 17, 31, 22, 22, 12, 16]
    }],
    chart: {
        height: 350,
        type: 'line',
    },
    stroke: {
        width: [0, 4]
    },
    title: {
        text: ''
    },
    dataLabels: {
        enabled: true,
        enabledOnSeries: [1]
    },
    labels: ['01 Jan  2022', '02 Jan  2022', '03 Jan  2022', '04 Jan  2022', '05 Jan  2022', '06 Jan  2022', '07 Jan  2022', '08 Jan  2022', '09 Jan  2022', '10 Jan  2022', '11 Jan  2022', '12 Jan  2022'],
    xaxis: {
        type: 'datetime'
    },
    yaxis: [{
        title: {
            text: 'Today Sale',
        },

    }, {
        opposite: true,
        title: {
            text: 'Product Stock'
        }
    }]
};

var chart = new ApexCharts(document.querySelector("#chartThree"), options)
chart.render();