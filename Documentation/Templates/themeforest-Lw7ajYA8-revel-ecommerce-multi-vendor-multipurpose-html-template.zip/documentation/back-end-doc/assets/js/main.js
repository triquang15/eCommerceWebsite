(function ($) {
    'use strict';
    $(window).on('load', function () {


        //------------------------------------------------------------------------------------------------------------------
        // Overlay Scroll Bar Init
        //------------------------------------------------------------------------------------------------------------------
        $(".scrollable").overlayScrollbars({});



        //------------------------------------------------------------------------------------------------------------------
        // Space In Window For Header
        //------------------------------------------------------------------------------------------------------------------
        $('body').has('.header').addClass('body-p-top')



        //------------------------------------------------------------------------------------------------------------------
        // Show Active Menu On Top In Main Sidebar
        //------------------------------------------------------------------------------------------------------------------
        if ($('.main-sidebar').length) {
            $('.sidebar-menu .os-viewport').animate({
                scrollTop: $('.sidebar-link.active').parents('.sidebar-item').offset().top - 90
            }, 0);
        }

    });

    $(document).ready(function () {
        //------------------------------------------------------------------------------------------------------------------
        // Main Content Height
        //------------------------------------------------------------------------------------------------------------------
        var windowHeight = $(window).height();
        $('.main-content').css('min-height', windowHeight - 70);
        if ($(window).width() < 1800) {
            $('.main-content').css('min-height', windowHeight - 60);
        }
        if ($(window).width() < 992) {
            $('.main-content').css('min-height', windowHeight - 50);
        }





        //------------------------------------------------------------------------------------------------------------------
        // Template Sidebar Dropdown
        //------------------------------------------------------------------------------------------------------------------
        $('.sidebar-link-group-title').on('click', function () {
            if (!$('.main-sidebar').hasClass('horizontal-menu')) {
                $(this).siblings('.sidebar-link-group').slideToggle(300);
            }
        });
        $('.sidebar-item').hover(function () {
            if ($('.main-sidebar').hasClass('horizontal-menu')) {
                $(this).find('.sidebar-link-group').toggleClass('show');
            }
        });
        $('.has-sub').on('click', function () {
            var dropdownId = $(this).attr('data-dropdown');
            if (!$('.main-sidebar').hasClass('horizontal-menu two-column-menu')) {
                if ($('.sidebar-link').hasClass('has-sub')) {
                    $(this).toggleClass('show');
                    $(this).siblings('.sidebar-dropdown-menu').slideToggle(300).parent('.sidebar-item');
                    $(this).parent('.sidebar-item').siblings().find('.sidebar-dropdown-menu').hide(300).siblings().removeClass("show");
                    $(this).parent('.sidebar-dropdown-item').siblings().children('.sidebar-link').removeClass('show');
                    $(this).parents('.sidebar-item').siblings().find('.sidebar-link').removeClass('show');
                    $(this).parent('.sidebar-dropdown-item').siblings().find('.sidebar-dropdown-menu').hide(300).siblings().removeClass("show");
                    $(this).parents('.sidebar-item').siblings().find('.sidebar-dropdown-menu').hide(300).siblings().removeClass("show");
                }
            }
            if ($('.main-sidebar').hasClass('two-column-menu')) {
                $(this).addClass('show');
                $('.main-sidebar').addClass('open-sub').removeClass('sub-menu-collapsed');
                $('#' + dropdownId).show().siblings('.sidebar-dropdown-menu').hide();
                $('.header').removeClass('expanded');
                $('body').removeClass('expanded');
            }
        });
        $(".sidebar-link").each(function () {
            var pageUrl = window.location.href.split(/[?#]/)[0];
            if (this.href == pageUrl) {
                $(this).addClass("active");
                if (!$('.main-sidebar').hasClass('horizontal-menu')) {
                    $(this).parents(".sidebar-item").addClass("open");
                }
            }
        });
        $('.sidebar-link.has-sub').parent().hover(function () {
            $(this).children('.sidebar-dropdown-menu').toggleClass('show');
        });
        $(".sidebar-menu .active").parent().parents(".sidebar-dropdown-menu").show().siblings().addClass("show");



        //------------------------------------------------------------------------------------------------------------------
        // Template Left Sidebar Collapse
        //------------------------------------------------------------------------------------------------------------------
        $(function () {
            $('#navClose').on('click', function (e) {
                e.preventDefault();
                e.stopPropagation();
                if ($(window).width() > 1199) {
                    $('body').has('.main-sidebar').find('.header').toggleClass('expanded')
                    $('.header .logo').toggleClass('small')
                    if (!$('.main-sidebar').hasClass('two-column-menu')) {
                        $('.main-sidebar').toggleClass('collapsed');
                    }
                    $('.body-padding').toggleClass('expanded')
                    $('.sidebar-link-group').show()
                } else {
                    $('.main-sidebar').toggleClass('sidebar-mini')
                    $('.main-sidebar').removeClass('collapsed')
                }
                if ($('.main-sidebar').hasClass('collapsed')) {
                    $(".sidebar-menu").overlayScrollbars().destroy();
                } else {
                    $(".sidebar-menu").overlayScrollbars({});
                }
                if ($('.main-sidebar').hasClass('two-column-menu')) {
                    $(".sidebar-menu").overlayScrollbars({});
                    $('.main-sidebar').toggleClass('sub-menu-collapsed').addClass('collapsed');
                    $('body').addClass('has-fixed-sidebar');
                }
            });
            $(document).on('click', function (e) {
                if ($(e.target).is('.main-sidebar *') === false) {
                    $('.main-sidebar').removeClass('sidebar-mini');
                    if ($(window).width() < 1200) {
                        if ($('.main-sidebar').hasClass('two-column-menu')) {
                            $('.main-sidebar').addClass('sub-menu-collapsed');
                        }
                    }
                }
            });
        });
    });
})(jQuery);